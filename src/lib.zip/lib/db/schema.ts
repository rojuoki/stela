/**
 * STELA database schema — Phase 6
 * Designed for SQLite now, PostgreSQL-portable later.
 * All timestamps stored as ISO-8601 strings.
 */

export const SCHEMA_SQL = `
-- Tracked X accounts
CREATE TABLE IF NOT EXISTS accounts (
  account_id    TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  display_name  TEXT,
  avatar_url    TEXT,
  created_at    TEXT,
  protected     INTEGER NOT NULL DEFAULT 0,
  fetched_at    TEXT NOT NULL
);

-- Excavation jobs
CREATE TABLE IF NOT EXISTS jobs (
  id            TEXT PRIMARY KEY,
  account_username TEXT NOT NULL,
  account_id    TEXT,
  requested_limit INTEGER NOT NULL DEFAULT 100,
  stage         INTEGER NOT NULL DEFAULT 1, -- Phase 4: Stage being excavated
  hold_id       TEXT, -- Phase 6: credit hold reference
  status        TEXT NOT NULL DEFAULT 'queued'
                CHECK(status IN ('queued','running','succeeded','failed','canceled')),
  error_code    TEXT,
  error_message TEXT,
  result_json   TEXT,
  api_calls     INTEGER NOT NULL DEFAULT 0,
  fetched_count INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL,
  started_at    TEXT,
  finished_at   TEXT,
  -- Set when a 429 occurs mid-job; cleared on completion.
  -- API layer returns status=waiting_rate_limit when this is set and in the future.
  resume_at     TEXT,
  -- JSON blob (ExcavationCheckpoint) persisted at each safe boundary so the
  -- job can continue from where it left off after a 429 suspend+resume.
  -- Cleared (NULL) when the job reaches a terminal state.
  resume_state  TEXT,
  -- OS process ID of the Node.js process that launched this job.
  -- Used by _init() to distinguish HMR-restart (same PID → job still alive)
  -- from a true process crash (different PID → safe to re-queue).
  node_pid      INTEGER
);

-- Stored tweets (earliest 100 per account)
CREATE TABLE IF NOT EXISTS tweets (
  post_id       TEXT PRIMARY KEY,
  account_id    TEXT NOT NULL REFERENCES accounts(account_id),
  created_at    TEXT NOT NULL,
  full_text     TEXT NOT NULL,
  media_json    TEXT,
  like_count    INTEGER NOT NULL DEFAULT 0,
  retweet_count INTEGER NOT NULL DEFAULT 0,
  reply_count   INTEGER NOT NULL DEFAULT 0,
  fetched_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tweets_account ON tweets(account_id, created_at ASC);

-- User unlock history (Phase 3: stage-aware unlock tracking)
CREATE TABLE IF NOT EXISTS unlocks (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       TEXT NOT NULL DEFAULT 'anonymous',
  account_id    TEXT NOT NULL,
  stage         INTEGER NOT NULL DEFAULT 1,  -- Stage unlocked (1, 2, 3, etc.)
  job_id        TEXT,
  unlocked_at   TEXT NOT NULL,
  UNIQUE(user_id, account_id, stage)  -- One unlock per user per account per stage
);
CREATE INDEX IF NOT EXISTS idx_unlocks_user_account ON unlocks(user_id, account_id);

-- Stage results per account (Phase 2: immutable Stage 1 results)
-- Each account can have multiple stages, but Stage 1 is immutable once created
CREATE TABLE IF NOT EXISTS stage_results (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id    TEXT NOT NULL REFERENCES accounts(account_id),
  stage         INTEGER NOT NULL,
  target_count  INTEGER NOT NULL,
  collected_count INTEGER NOT NULL,
  status        TEXT NOT NULL,  -- maps to ExcavationResult.stopReason
  job_id        TEXT NOT NULL REFERENCES jobs(id),
  created_at    TEXT NOT NULL,
  UNIQUE(account_id, stage)  -- one result per account per stage
);
CREATE INDEX IF NOT EXISTS idx_stage_results_account ON stage_results(account_id, stage);

-- Credit system tables (Phase 6)

-- User subscriptions (plan, cycle)
CREATE TABLE IF NOT EXISTS subscriptions (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  plan          TEXT NOT NULL DEFAULT 'basic', -- 'basic' for MVP
  cycle_start   TEXT NOT NULL,
  cycle_end     TEXT NOT NULL,
  credits_per_cycle INTEGER NOT NULL DEFAULT 3,
  status        TEXT NOT NULL DEFAULT 'active'
                CHECK(status IN ('active','canceled','expired')),
  created_at    TEXT NOT NULL,
  UNIQUE(user_id)
);

-- Credit balances per user
CREATE TABLE IF NOT EXISTS credits (
  user_id       TEXT PRIMARY KEY,
  balance       INTEGER NOT NULL DEFAULT 0,
  total_earned  INTEGER NOT NULL DEFAULT 0,
  total_spent   INTEGER NOT NULL DEFAULT 0,
  updated_at    TEXT NOT NULL
);

-- Credit holds with TTL (prevent double-spend)
CREATE TABLE IF NOT EXISTS credit_holds (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  job_id        TEXT NOT NULL REFERENCES jobs(id),
  amount        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL,
  expires_at    TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'held'
                CHECK(status IN ('held','captured','released')),
  UNIQUE(job_id)
);
CREATE INDEX IF NOT EXISTS idx_credit_holds_expires ON credit_holds(expires_at);

-- Credit events audit log
CREATE TABLE IF NOT EXISTS credit_events (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       TEXT NOT NULL,
  job_id        TEXT,
  hold_id       TEXT,
  event_type    TEXT NOT NULL 
                CHECK(event_type IN ('earned','held','captured','released','expired')),
  amount        INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  reason        TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_credit_events_user ON credit_events(user_id, created_at DESC);

-- Auth users
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- API call telemetry (dev only; populated by xclient + cache routes)
-- cached=0 → real HTTP call to X API
-- cached=1 → request served from local cache (call saved)
CREATE TABLE IF NOT EXISTS api_call_log (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  endpoint  TEXT    NOT NULL,
  cached    INTEGER NOT NULL DEFAULT 0,
  ts        TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_api_call_log_ts ON api_call_log(ts DESC);

-- Temporary unlock results (Phase 2: for guest users before account creation)
CREATE TABLE IF NOT EXISTS temporary_unlocks (
  token       TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL,
  username    TEXT NOT NULL,
  tweets_json TEXT NOT NULL,  -- JSON array of tweet data
  job_id      TEXT,           -- Associated excavation job ID for progress tracking
  created_at  TEXT NOT NULL,
  expires_at  TEXT NOT NULL,
  consumed    INTEGER NOT NULL DEFAULT 0  -- 1 when transferred to user account
);
CREATE INDEX IF NOT EXISTS idx_temporary_unlocks_expires ON temporary_unlocks(expires_at);
CREATE INDEX IF NOT EXISTS idx_temporary_unlocks_consumed ON temporary_unlocks(consumed);
`;
