import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    if (!process.env.STRIPE_PRICE_BASIC) {
      return NextResponse.json({ error: "Stripe configuration missing" }, { status: 500 });
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{
        price: process.env.STRIPE_PRICE_BASIC,
        quantity: 1,
      }],
      metadata: {
        userId: user.id,
        type: 'subscription', // Extensible for future: 'credit', 'unlock', etc.
        plan: 'basic'
      },
      success_url: `${process.env.NEXT_PUBLIC_BASE_URL}/?subscription=success`,
      cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/subscribe`,
    });

    return NextResponse.json({ checkoutUrl: session.url });
  } catch (error) {
    console.error("[checkout/subscription] Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}