import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import Stripe from 'stripe';
import { createOrUpdateSubscription } from "@/lib/repository";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(req: NextRequest) {
  const body = await req.text();
  const headersList = await headers();
  const sig = headersList.get('stripe-signature') as string;

  try {
    const event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    
    console.log(`[stripe/webhook] Received event: ${event.type}`);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        
        // Debug logging to understand the structure
        console.log('[stripe/webhook] Session ID:', session.id);
        console.log('[stripe/webhook] Session mode:', session.mode);
        console.log('[stripe/webhook] Session metadata:', JSON.stringify(session.metadata));
        console.log('[stripe/webhook] Full session object keys:', Object.keys(session));
        
        const metadata = session.metadata || {};
        const { userId, type } = metadata;
        
        if (!userId) {
          console.error("[stripe/webhook] Missing userId in session metadata. Available metadata:", metadata);
          return NextResponse.json({ error: "Missing userId" }, { status: 400 });
        }

        if (!type) {
          console.error("[stripe/webhook] Missing type in session metadata. Available metadata:", metadata);
          return NextResponse.json({ error: "Missing purchase type" }, { status: 400 });
        }

        // Handle different purchase types - extensible design
        switch (type) {
          case 'subscription': {
            const plan = (metadata.plan as 'basic') || 'basic';
            console.log(`[stripe/webhook] Processing subscription for user ${userId}, plan: ${plan}`);
            
            try {
              createOrUpdateSubscription(userId, plan, 4);
              console.log(`[stripe/webhook] Subscription activated successfully for user ${userId}`);
            } catch (error) {
              console.error(`[stripe/webhook] Failed to activate subscription for user ${userId}:`, error);
              return NextResponse.json({ error: "Failed to activate subscription" }, { status: 500 });
            }
            break;
          }
          
          // Future extension points:
          // case 'credit': {
          //   const amount = parseInt(metadata.creditAmount || '1');
          //   giveCredits(userId, amount, 'Credit package purchase');
          //   break;
          // }
          // 
          // case 'unlock': {
          //   const accountId = metadata.accountId;
          //   // Handle one-time unlock purchase
          //   break;
          // }
          
          default: {
            console.error(`[stripe/webhook] Unknown purchase type: ${type}. Available metadata:`, metadata);
            return NextResponse.json({ error: "Unknown purchase type" }, { status: 400 });
          }
        }
        break;
      }
      
      default:
        console.log(`[stripe/webhook] Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("[stripe/webhook] Error:", error);
    return NextResponse.json({ error: "Webhook error" }, { status: 400 });
  }
}